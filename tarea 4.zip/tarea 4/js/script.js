const usuarioInput = document.getElementById('username');
const passwordInput = document.getElementById('password');
const mostrarContraButton = document.getElementById('showPassword');
const form = document.getElementById('form');
const loader = document.getElementById('loader');
const mensaje = document.getElementById('mensaje');

mostrarContraButton.addEventListener('click', () => {
    if (passwordInput.type === 'password') {
        passwordInput.type = 'text';
        mostrarContraButton.textContent = 'Ocultar';
    } else {
        passwordInput.type = 'password';
        mostrarContraButton.textContent = 'Mostrar';
    }
});

form.addEventListener('submit', (e) => {
    e.preventDefault();
    loader.style.display = 'block';
    mensaje.style.display = 'none';

    setTimeout(() => {
        loader.style.display = 'none';
        const username = usuarioInput.value;
        const password = passwordInput.value;

        // aquí están las credenciales correctas
        if (username === 'usuario' && password === 'contraseña') {
            mensaje.textContent = '¡Inicio de sesión exitoso!';
            mensaje.style.color = 'green';
            usuarioInput.style.borderColor = 'green';
            passwordInput.style.borderColor = 'green';
        } else {
            mensaje.textContent = 'Credenciales incorrectas. Inténtalo de nuevo.';
            mensaje.style.color = 'red';
            usuarioInput.style.borderColor = 'red';
            passwordInput.style.borderColor = 'red';
        }

        mensaje.style.display = 'block';
    }, 1000); // Simulación de una solicitud de inicio de sesión
});
